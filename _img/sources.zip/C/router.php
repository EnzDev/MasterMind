<?php
require_once "V/error.php";
require_once "V/game.php";
require_once "V/home.php";
require_once "V/results.php";


require_once 'C/authCtrl.php';
require_once 'C/gameCtrl.php';

// session_start();
/**
 *
 */

class router {
  private $authCtl;
  function __construct() {
    $this->authCtl = new AuthCtl();
    $this->gameCtl = new GameCtl();
  }

  public function routerReq()  {
    // print_r("lol");
    if (isset($_POST["username"]) && !empty($_POST["username"])){
      switch ($this->authCtl->auth($_POST["username"],$_POST["password"])) {
        case 0:
          $_SESSION["online"] = true;
          $_SESSION["username"] = $_POST["username"];
          $this->gameCtl->launch();
          break;
        case -1:
          $_SESSION["alert"] = "Mot de passe invalide, réessayez";
          (new Home())->launch();
          break;
        case -2:
          $_SESSION["alert"] = "Nom d'utilisateur inconnu";
          (new Home())->launch();
          break;
      }
    }elseif (!isset($_SESSION["online"]) || $_SESSION["online"]==false){ (new Home())->launch();
    }elseif ($_SESSION["online"]==true) {
      if (isset($_POST["play"])) {

        $this->gameCtl->play($_POST["play"]);
      }

      // print_r(isset($_POST["new"]));
      $this->gameCtl->launch();
    }else { // Not normal...
      (new errorV())->raise();
    }

  }
}

?>
