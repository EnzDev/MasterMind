<?php
require_once "M/game.php";
require_once "V/game.php";

if(!isset($_SESSION)){
    session_start();
}

class GameCtl{

    function __construct($new=false){
    if (!isset($_SESSION["game"])) {
      $_SESSION["game"] = new Game();
      // print_r("lol");
    }
    // print_r("OK ?");
  }

  function launch(){
    // print_r( $_SESSION["game"]);
    $test = $_SESSION["game"]->proposition;
    $res = $_SESSION["game"]->results;
    $len = count($test);
    (new GameView())->launch($test, $res,$len);
  }

  function play($move){
    print_r($move);

    $assoc = array('red'=>"rouge", 'green'=>"vert", 'blue'=>"bleu", 'orange'=>"orange", 'white'=>"blanc", 'purple'=>"violet", 'pink'=>"fuchsia", 'yellow'=>"jaune");
    foreach ($move as &$m) {
      $m = $assoc[$m];
    }
    $res = $_SESSION["game"]->play($move);
  }

}
