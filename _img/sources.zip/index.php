<?php

require_once "C/router.php";

$route=new Router();

$route->routerReq();

?>
