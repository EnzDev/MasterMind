<?php
/**
 * Game model class : define the way of the game works
 */
class Game {
  public $solution;
  public $proposition;
  public $results;

  public $COLORS = array("rouge", "jaune", "vert", "bleu", "orange", "blanc", "violet", "fuchsia");

  function __construct(){
    $this->proposition = array();
    $this->results      = array();
    $this->solution    = array();
    for ($n=0; $n < 4; $n++) {
      $this->solution[$n] = randomElement($this->COLORS);
    }

  }

  // take an array and return the states
  // 0 : invalid/wrong
  // 1 : missplaced
  // 2 : correct
  public function testACase($testArray){
    $states = array();
    $testArrayM = $testArray;
    foreach ($this->solution as $key => $value) {
      if ($value==$testArrayM[$key]) {
        // echo $this->solution[$key]." = ".$value."<br>";
        $states[$key] = 2;
        // $testArrayM[$key] = "modified";
      }elseif (in_array($value,$testArrayM) ) {
        // echo $value." in ".implode("|",$this->solution)."<br>";
        $states[$key] = 1;
      }else{
        // echo $value." not in ".implode("|",$this->solution)."<br>";
        $states[$key] = 0;
      }
    }

    return $states;
  }

  public function hasWin($testArray) {
    return array(2,2,2,2) == $this->testACase($testArray);
  }

  /**
  * Consider that $case contain 4 elements that are in the $COLORS
  */
  public function play($case){
    $this->proposition[] = $case;
    print_r($case);
    $this->results[] = $this->testACase($case);
    print_r($case);
    return $this->hasWin($case);
  }

  function sout(){
    print_r($this->solution);
    print_r($this->proposition);
  }

  public function isTheEnd(){
    return count($this->proposition)==10;
  }

}


// Function to pick a random element (picked from php.net "sam barrow's functions")
function randomElement(array $array)
{
    if (count($array) === 0){
        trigger_error('Array is empty.',  E_USER_WARNING);
        return null;
    }

    $rand = mt_rand(0, count($array) - 1);
    $array_keys = array_keys($array);

    return $array[$array_keys[$rand]];
}
