<?php class GameView{
  function __construct(){}
  function launch($test, $res, $len, $finished=false){
$assoc = array("rouge"=>'red', "vert"=>'green', "bleu"=>'blue', "orange"=>'orange', "blanc"=>'white', "violet"=>'purple', "fuchsia"=>'pink', "jaune"=>'yellow');
$points = array(0 =>"undefined" ,1=>"white", 2=>"black" );
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Master-Mind&#160;</title>
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
    <link rel="shortcut icon" href="/img/logo.png">
    <link rel="stylesheet" href="/style/reset.css" media="screen" title="no title">
    <link rel="stylesheet" href="/style/game.css" media="screen" title="no title">

     <!-- ECMAscript 6 -->
    <script type="text/javascript">
      setInterval(()=>{
          tit = document.title
          tit = tit.substring(1)+tit.substring(0,1)
          document.title = tit
        },800)
    </script>

  </head>
  <body>
    <div id="container">
      <!-- <div style="width:5vw;"></div> -->
      <div id="board">

        <div id="before"><span id="title">Mastermind</span><span id="id">Connecté en tant que <a href="/disconnect.php"><?php echo $_SESSION["username"] ?></a></span></div>

        <div id="head"> <!-- Four dots for each try-->
          <!-- ul (flex) for each try -->
          <?php for ($i=0; $i <10 ; $i++) { ?>
            <ul>
            <?php for ($j=0; $j < 4; $j++) { ?>
              <li class="<?php print_r(isset($res[$i][$j]) ? $points[$res[$i][$j]] : 'undefined') ?>"></li>
            <?php } ?>
          </ul>
          <?php } ?>
        </div>

        <div id="try">
          <?php for ($i=0; $i <10 ; $i++) { ?>

            <ul <?php if ($i==$len) { echo 'class="current"'; } ?>>
            <?php for ($j=0; $j < 4; $j++) { ?>
              <li class="<?php echo isset($test[$i][$j])?$assoc[$test[$i][$j]]:'undefined' ?>"></li>
            <?php } ?>
          </ul>
          <?php } ?>
        </div>
        <div id="colors">
          <ul> <!-- or unrevealed -->
            <li class="red"></li> <!-- A clic on one of these add the color -->
            <li class="green"></li>
            <li class="blue"></li>
            <li class="yellow"></li>
            <li class="orange"></li>
            <li class="white"></li>
            <li class="purple"></li>
            <li class="pink"></li>
          </ul>
        </div>
      </div>
      <div id="result">
        <ul style="height:12vh;"></ul> <!-- placeholder for the flex alignement; -->
        <ul style="height:6vh;"></ul> <!-- placeholder for the flex alignement; -->
        <ul class="<?php echo $finished==false?'unrevealed':'revealed' ?>" id="solution"> <!-- or unrevealed -->
          <?php for ($c=0; $c < 4 ; $c++) { ?>
            <li class="<?php echo $finished==false?'undefined':$finished[$c] ?>"></li>
          <?php } ?>
        </ul>
        <ul id="submit" style="height:10vh;">Soumettre mon essai</ul> <!-- submit link -->
      </div>
    </div>
    <div id="noise"></div>

    <script type="text/javascript" >
    var n = [0,1,2,3]
    var values = [0,1,2,3]

    function tooglePlayable(plyble){
      if (plyble) {
          $("#submit").click(
            ()=>{
              submit = [];
              $(".current li").each(function(){submit.push($(this).attr("class"))})
              $.post("/", {play:submit},function(){location.replace("/")});
              // location.reload();
            }
          ).attr("class","ok")
      }else {
        $("#submit").unbind().attr("class","")
      }
    }

    function Gameadd(name) {
      n.sort()
      var x = n.pop();
      $($(".current li")[x]).attr("class",name);

      $($(".current li")[x]).click(()=>{
        $($(".current li")[x]).attr("class","undefined");
        n.push(x);
        $($(".current li")[x]).unbind();
        tooglePlayable(false);
      })

      if ($(".current li:not(.undefined)").length == 4){tooglePlayable(true);}
    }

    $("#colors li").click(function() {
      Gameadd( $(this).attr("class") );
    });
    </script>
  </body>
</html>
<?php }}
