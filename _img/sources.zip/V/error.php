<?php
/**
 *
 */
class errorV {

  function __construct(){}
  function raise(){
    ?>Mheeeeeeee !<?php
  }
}
